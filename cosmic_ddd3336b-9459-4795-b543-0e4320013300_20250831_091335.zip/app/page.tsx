'use client';

import dynamic from 'next/dynamic';
import Hero from '@/app/components/Hero';
import { motion } from 'framer-motion';

const PromptGrid = dynamic(() => import('@/app/components/PromptGrid'), {
  ssr: true,
  loading: () => (
    <div className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-square rounded-2xl border border-white/10 bg-white/5 animate-pulse" />
          ))}
        </div>
      </div>
    </div>
  )
});

const PromptEnhancer = dynamic(() => import('@/app/components/PromptEnhancer'), {
  ssr: false,
  loading: () => (
    <section className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="h-64 rounded-2xl border border-white/10 bg-white/5 animate-pulse" />
      </div>
    </section>
  )
});

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Content */}
      <div className="relative z-10">
        <main>
          <Hero />
          <div style={{ contentVisibility: 'auto' }}>
            <PromptGrid />
          </div>
          
          {/* Prompt Enhancer Section */}
          <div className="relative" style={{ contentVisibility: 'auto' }}>
            {/* Section separator */}
            <motion.div
              initial={{ opacity: 0, scaleX: 0 }}
              whileInView={{ opacity: 1, scaleX: 1 }}
              viewport={{ once: true }}
              className="h-px bg-gradient-to-r from-transparent via-red-500/50 to-transparent mx-8"
            />
            
            <PromptEnhancer />
          </div>

          {/* Coming Soon Section */}
          <motion.section
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="py-20 px-4 sm:px-6 lg:px-8 text-center"
            style={{ contentVisibility: 'auto' }}
          >
            <motion.div
              animate={{ 
                y: [0, -10, 0],
                scale: [1, 1.02, 1]
              }}
              transition={{ 
                duration: 4, 
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="inline-block bg-gradient-to-r from-red-500/20 to-red-600/20 backdrop-blur-sm border border-red-500/30 rounded-2xl p-8 max-w-lg"
            >
              <div className="text-2xl mb-4">🚀</div>
              <h3 className="text-2xl font-light text-white mb-4">
                Sell Your Prompts – <span className="text-red-400">Coming Soon</span>
              </h3>
              <p className="text-white/70 font-light mb-6">
                Soon you&apos;ll be able to upload and sell your own cinematic prompts. 
                Join the waitlist to be notified when creator tools go live.
              </p>
              
              {/* Waitlist Form */}
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  placeholder="Enter your email"
                  className="flex-1 bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-light"
                />
                <button className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-3 rounded-lg transition-all font-light">
                  Join Waitlist
                </button>
              </div>
            </motion.div>
          </motion.section>
        </main>
      </div>
    </div>
  );
}