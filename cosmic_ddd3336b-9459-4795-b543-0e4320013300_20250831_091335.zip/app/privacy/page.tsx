'use client';

import Navigation from '@/app/components/Navigation';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen">
      <div className="fixed inset-0 -z-10" style={{ background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)' }} />
      <div className="relative z-10">
        <Navigation />
        <main className="pt-24 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-3xl rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 text-white/85">
            <h1 className="text-3xl font-light text-white mb-4">Privacy Policy</h1>
            <p className="text-sm font-light text-white/80">
              We respect your privacy. Promptopiya does not sell, rent, or trade your personal information. Any data collected (such as your email address and account details) is used only for product access, account verification, and customer support. Payments are processed securely through trusted third-party providers—we never store sensitive payment information on our servers.
            </p>
          </div>
          <div className="h-10" />
        </main>
      </div>
    </div>
  );
}
