'use client';

import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import Navigation from '@/app/components/Navigation';

function useCountUp(end: number, durationMs = 1500) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min(1, (t - start) / durationMs);
      setValue(Math.floor(end * (1 - Math.pow(1 - p, 3))));
      if (p < 1) requestAnimationFrame(tick);
    };
    const r = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(r);
  }, [end, durationMs]);
  return value;
}

const reviews = [
  { text: 'Absolutely blown away by the consistency of results. Feels like having a pro studio in my pocket!', name: 'Arjun P.' },
  { text: 'No travel, no wardrobe, still I look like a fashion influencer. Worth every dollar!', name: 'Maya S.' },
  { text: 'I saved thousands on photo shoots. Promptopiya is the future of content creation.', name: 'David K.' },
  { text: 'Super smooth buying process. Downloaded instantly and worked like magic!', name: 'Sana R.' },
  { text: 'I was skeptical, but now every IG post looks cinematic. Game-changer!', name: 'Rohit G.' },
  { text: 'Love the instant downloads and library system. No more hunting for prompts.', name: 'Meera L.' },
  { text: 'So easy, even I could start looking like a pro model in minutes.', name: 'Samir P.' },
  { text: 'Customer support is great. Kartik and team really care about the users.', name: 'Ananya M.' },
  { text: 'Best $10 I ever spent. Period.', name: 'John T.' },
];

export default function ReviewsPage() {
  const prompts = useCountUp(10000);
  const customers = useCountUp(3500);
  const satisfaction = useCountUp(99);

  return (
    <div className="min-h-screen">
      <div className="fixed inset-0 -z-10" style={{ background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)' }} />
      <div className="relative z-10">
        <Navigation />

        <main className="pt-24 px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <section className="text-center max-w-3xl mx-auto">
            <motion.h1 initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="text-4xl sm:text-5xl text-white font-semibold">
              ⭐ Trusted by creators worldwide
            </motion.h1>
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }} className="mt-4 text-white/70 font-light">
              See what our happy customers say about Promptopiya
            </motion.p>
          </section>

          {/* Stats */}
          <section className="mt-10 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-5xl mx-auto">
            {[
              { label: 'Prompts Delivered', value: prompts, suffix: '+' },
              { label: 'Happy Customers', value: customers, suffix: '+' },
              { label: 'Satisfaction', value: satisfaction, suffix: '%' },
            ].map((s, i) => (
              <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: i * 0.1 }} className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-6 text-center">
                <div className="text-4xl text-white font-light">{s.value.toLocaleString()}{s.suffix}</div>
                <div className="mt-1 text-white/70 text-sm font-light">{s.label}</div>
              </motion.div>
            ))}
          </section>

          {/* Reviews grid */}
          <section className="mt-12 max-w-6xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {reviews.map((r, idx) => (
                <motion.div key={idx} initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: (idx % 6) * 0.05 }} className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-sm p-5">
                  <div className="flex items-center gap-3 mb-3">
                    <img src={`https://i.pravatar.cc/80?u=reviewer_${idx}`} alt={r.name} className="h-10 w-10 rounded-full object-cover" />
                    <div>
                      <div className="text-white text-sm font-medium">{r.name}</div>
                      <div className="text-yellow-300 text-xs">★★★★★</div>
                    </div>
                  </div>
                  <p className="text-white/80 text-sm font-light">“{r.text}”</p>
                </motion.div>
              ))}
            </div>
          </section>

          {/* About Us */}
          <section id="about" className="mt-20 max-w-4xl mx-auto text-center">
            <motion.h2 initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} className="text-3xl sm:text-4xl text-white font-light">
              🚀 About Promptopiya
            </motion.h2>
            <motion.p initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.1 }} className="mt-4 text-white/75 font-light">
              Redefining how influencers create content.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.15 }} className="mt-6 text-white/80 font-light space-y-3 text-sm text-left sm:text-center">
              <p>Promptopiya was founded by Kartik Kumawat, a digital creator passionate about making high-quality influencer content affordable and accessible. We believe creativity shouldn’t require expensive studios, clothes, or endless travel.</p>
              <p>With AI-powered prompts, you can:</p>
              <ul className="list-disc list-inside text-white/80">
                <li>Become a fashion influencer with just $10.</li>
                <li>Create cinematic photoshoots without leaving your home.</li>
                <li>Maintain perfect character consistency across all your posts.</li>
                <li>Save time, money, and effort—focus only on growing your audience.</li>
              </ul>
            </motion.div>
            <div className="mt-8">
              <a href="/pricing" className="inline-flex items-center justify-center rounded-lg bg-gradient-to-r from-red-500 to-red-600 px-6 py-3 text-white shadow-[0_0_30px_rgba(255,0,0,0.25)] transition-transform hover:scale-[1.02]">
                Start for $10
              </a>
            </div>
          </section>

          <div className="h-12" />
        </main>
      </div>
    </div>
  );
}
