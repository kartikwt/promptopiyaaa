'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Icon } from '@iconify/react';
import { useAuth } from 'cosmic-authentication';
import Navigation from '@/app/components/Navigation';

interface Prompt {
  id: string;
  title: string;
  description: string;
  subcategory: string;
  thumbnailUrl: string;
  pdfUrl?: string;
  status: 'draft' | 'published';
  createdAt: string;
}

interface Category {
  id: string;
  name: string;
  slug: string;
}

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export default function AdminPage() {
  const { user, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState('upload');
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  
  // Upload form state
  const [uploadForm, setUploadForm] = useState({
    title: '',
    description: '',
    subcategory: '',
    thumbnails: [] as File[],
    pdf: null as File | null,
    status: 'published' as 'published' | 'draft',
  });

  // Ensure default subcategory is set once categories are loaded
  useEffect(() => {
    if (!uploadForm.subcategory && categories.length > 0) {
      setUploadForm((prev) => ({ ...prev, subcategory: categories[0].name }));
    }
  }, [categories, uploadForm.subcategory]);

  // New category form
  const [newCategory, setNewCategory] = useState('');

  // Stats
  const [stats, setStats] = useState({
    totalPrompts: 0,
    totalPurchases: 0,
    totalCreditsEarned: 0,
    totalEnhancements: 0
  });

  useEffect(() => {
    if (!authLoading && user) {
      void fetchData();
    }
  }, [authLoading, user]);

  const fetchData = async () => {
    try {
      await Promise.all([
        fetchPrompts(),
        fetchCategories(),
        fetchStats()
      ]);
    } catch (error) {
      console.error('Error fetching admin data:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPrompts = async () => {
    try {
      const response = await fetch('/api/admin/prompts');
      if (response.ok) {
        const data = await response.json();
        setPrompts(data.prompts || []);
      }
    } catch (error) {
      console.error('Error fetching prompts:', error);
    }
  };

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/admin/categories');
      if (response.ok) {
        const data = await response.json();
        setCategories(data.categories || []);
      }
    } catch (error) {
      console.error('Error fetching categories:', error);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch('/api/admin/stats');
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error('Error fetching stats:', error);
    }
  };

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!uploadForm.title || !uploadForm.description || uploadForm.thumbnails.length < 1 || !uploadForm.pdf) {
      alert('Please fill in all fields, select 1–2 thumbnails and a PDF.');
      return;
    }
    if (uploadForm.thumbnails.length > 2) {
      alert('Please select no more than 2 thumbnails.');
      return;
    }

    setUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('title', uploadForm.title);
      formData.append('description', uploadForm.description);
      formData.append('subcategory', uploadForm.subcategory);
      formData.append('status', uploadForm.status);
      uploadForm.thumbnails.forEach((f) => formData.append('thumbnails', f));
      formData.append('pdf', uploadForm.pdf);

      const response = await fetch('/api/admin/prompts/upload', {
        method: 'POST',
        body: formData,
      });

      if (response.ok) {
        alert('Prompt uploaded successfully!');
        setUploadForm({
          title: '',
          description: '',
          subcategory: categories[0]?.name || '',
          thumbnails: [],
          pdf: null,
          status: 'published',
        });
        // Reset file inputs
        const fileInputs = document.querySelectorAll('input[type="file"]') as NodeListOf<HTMLInputElement>;
        fileInputs.forEach(input => { input.value = ''; });
        
        void fetchPrompts(); // Refresh the prompts list
      } else {
        const err = await response.json().catch(() => ({ error: 'Upload failed' }));
        alert(err.error || 'Upload failed. Please try again.');
      }
    } catch (error) {
      console.error('Error uploading prompt:', error);
      alert('Upload failed. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleDeletePrompt = async (promptId: string) => {
    if (!confirm('Are you sure you want to delete this prompt?')) return;

    try {
      const response = await fetch(`/api/admin/prompts/${promptId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        void fetchPrompts(); // Refresh the list
      } else {
        throw new Error('Delete failed');
      }
    } catch (error) {
      console.error('Error deleting prompt:', error);
      alert('Delete failed. Please try again.');
    }
  };

  const togglePromptStatus = async (promptId: string, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'published' ? 'draft' : 'published';
      const response = await fetch(`/api/admin/prompts/${promptId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        void fetchPrompts(); // Refresh the list
      } else {
        const err = await response.json().catch(() => ({ error: 'Status update failed' }));
        alert(err.error || 'Status update failed. Please try again.');
      }
    } catch (error) {
      console.error('Error updating prompt status:', error);
      alert('Status update failed. Please try again.');
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!newCategory.trim()) return;

    try {
      const response = await fetch('/api/admin/categories', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name: newCategory.trim() }),
      });

      if (response.ok) {
        setNewCategory('');
        void fetchCategories(); // Refresh categories
      } else {
        const err = await response.json().catch(() => ({ error: 'Category creation failed' }));
        alert(err.error || 'Failed to add category. Please try again.');
      }
    } catch (error) {
      console.error('Error adding category:', error);
      alert('Failed to add category. Please try again.');
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    if (!confirm('Are you sure you want to delete this category?')) return;

    try {
      const response = await fetch(`/api/admin/categories/${categoryId}`, {
        method: 'DELETE',
      });

      if (response.ok) {
        void fetchCategories(); // Refresh categories
      } else {
        const err = await response.json().catch(() => ({ error: 'Category deletion failed' }));
        alert(err.error || 'Failed to delete category. Please try again.');
      }
    } catch (error) {
      console.error('Error deleting category:', error);
      alert('Failed to delete category. Please try again.');
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black">
        <div className="animate-spin rounded-full h-12 w-12 border-2 border-red-500/30 border-t-red-500"></div>
      </div>
    );
  }

  // Restrict access strictly to the specified admin email
  if (!user || user.email !== ADMIN_EMAIL) {
    return (
      <div className="min-h-screen">
        <div 
          className="fixed inset-0 z-0" 
          style={{ background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)' }}
        />
        <div className="relative z-10">
          <Navigation />
          <main className="pt-24 px-4">
            <div className="mx-auto max-w-xl rounded-xl border border-white/15 bg-white/5 p-6 text-center text-white/80 backdrop-blur-sm">
              <Icon icon="mdi:lock" className="mx-auto mb-3 h-8 w-8 text-red-300" />
              <p className="font-light">Access restricted. Please sign in with the authorized admin account.</p>
            </div>
          </main>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      {/* Background */}
      <div 
        className="fixed inset-0 z-0" 
        style={{
          background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)'
        }}
      />
      
      <div className="relative z-10">
        <Navigation />
        
        <main className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-8"
            >
              <h1 className="text-4xl font-light text-white mb-4">
                Admin <span className="text-red-400">Panel</span>
              </h1>
              <p className="text-white/70 font-light">
                Manage prompts, categories, and view analytics for Promptopiya.
              </p>
            </motion.div>

            {/* Stats Cards */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8"
            >
              {[
                { label: 'Total Prompts', value: stats.totalPrompts, icon: 'mdi:image-multiple' },
                { label: 'Total Purchases', value: stats.totalPurchases, icon: 'mdi:cart' },
                { label: 'Credits Earned', value: stats.totalCreditsEarned, icon: 'icon-park:credit' },
                { label: 'AI Enhancements', value: stats.totalEnhancements, icon: 'mdi:magic-staff' },
              ].map((stat, index) => (
                <div key={index} className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-white/70 text-sm font-light">{stat.label}</p>
                      <p className="text-2xl font-light text-white">{stat.value}</p>
                    </div>
                    <Icon icon={stat.icon} className="w-8 h-8 text-red-400" />
                  </div>
                </div>
              ))}
            </motion.div>

            {/* Tab Navigation */}
            <div className="flex space-x-1 bg-white/5 backdrop-blur-sm rounded-lg p-1 mb-8">
              {['upload', 'manage', 'categories'].map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`flex-1 py-2 px-4 rounded-md transition-all font-light capitalize ${
                    activeTab === tab
                      ? 'bg-red-500 text-white'
                      : 'text-white/70 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {tab === 'upload' && <Icon icon="mdi:upload" className="w-4 h-4 mr-2 inline" />}
                  {tab === 'manage' && <Icon icon="mdi:cog" className="w-4 h-4 mr-2 inline" />}
                  {tab === 'categories' && <Icon icon="mdi:tag-multiple" className="w-4 h-4 mr-2 inline" />}
                  {tab}
                </button>
              ))}
            </div>

            {/* Tab Content */}
            {activeTab === 'upload' && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-8"
              >
                <h2 className="text-2xl font-light text-white mb-6">Upload New Prompt</h2>
                
                <form onSubmit={handleUpload} className="space-y-6">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-white font-light mb-2">Title *</label>
                      <input
                        type="text"
                        value={uploadForm.title}
                        onChange={(e) => setUploadForm({ ...uploadForm, title: e.target.value })}
                        className="w-full bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-light"
                        placeholder="e.g., Fashion Influencer Studio Portrait"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-white font-light mb-2">Category *</label>
                      <select
                        value={uploadForm.subcategory}
                        onChange={(e) => setUploadForm({ ...uploadForm, subcategory: e.target.value })}
                        className="w-full bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-light"
                        required
                      >
                        {categories.map((c) => (
                          <option key={c.id} value={c.name}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-white font-light mb-2">Description *</label>
                    <textarea
                      value={uploadForm.description}
                      onChange={(e) => setUploadForm({ ...uploadForm, description: e.target.value })}
                      className="w-full h-24 bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white placeholder-white/40 resize-none focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-light"
                      placeholder="Short 150–200 character description..."
                      required
                    />
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-white font-light mb-2">Thumbnails (1–2, 1:1) *</label>
                      <input
                        type="file"
                        accept="image/*"
                        multiple
                        onChange={(e) => setUploadForm({ ...uploadForm, thumbnails: Array.from(e.target.files || []) })}
                        className="w-full bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-light file:bg-red-500 file:text-white hover:file:bg-red-600"
                        required
                      />
                      <p className="text-white/40 text-xs font-light mt-1">Upload 1–2 perfectly square JPG/PNG thumbnails.</p>

                      {/* Preview grid */}
                      <div className="mt-3 grid grid-cols-3 gap-2">
                        {uploadForm.thumbnails.map((f, idx) => (
                          <div key={idx} className="aspect-square overflow-hidden rounded-md border border-white/10">
                            <img src={URL.createObjectURL(f)} alt="thumbnail preview" className="h-full w-full object-cover" />
                          </div>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-white font-light mb-2">PDF File *</label>
                      <input
                        type="file"
                        accept=".pdf"
                        onChange={(e) => setUploadForm({ ...uploadForm, pdf: e.target.files?.[0] || null })}
                        className="w-full bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3 text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-light file:bg-red-500 file:text-white hover:file:bg-red-600"
                        required
                      />
                      <p className="text-white/40 text-xs font-light mt-1">Upload the private PDF prompt file.</p>

                      <label className="mt-4 block text-white font-light">Status</label>
                      <select
                        value={uploadForm.status}
                        onChange={(e) => setUploadForm({ ...uploadForm, status: e.target.value as 'published' | 'draft' })}
                        className="mt-2 w-full rounded-lg border border-white/20 bg-black/30 px-3 py-2 text-white"
                      >
                        <option value="published">Live</option>
                        <option value="draft">Draft</option>
                      </select>
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={uploading}
                    className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 disabled:opacity-50 disabled:cursor-not-allowed text-white px-8 py-3 rounded-lg transition-all font-light flex items-center space-x-2"
                  >
                    {uploading ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white/30 border-t-white" />
                        <span>Uploading...</span>
                      </>
                    ) : (
                      <>
                        <Icon icon="mdi:upload" className="w-5 h-5" />
                        <span>Upload Prompt</span>
                      </>
                    )}
                  </button>
                </form>
              </motion.div>
            )}

            {activeTab === 'manage' && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-light text-white">Manage Prompts</h2>
                
                {loading ? (
                  <div className="text-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-2 border-red-500/30 border-t-red-500 mx-auto"></div>
                  </div>
                ) : (
                  <div className="grid gap-4">
                    {prompts.map((prompt) => (
                      <div
                        key={prompt.id}
                        className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6 flex items-center justify-between"
                      >
                        <div className="flex items-center space-x-4">
                          <img
                            src={prompt.thumbnailUrl}
                            alt={prompt.title}
                            className="w-12 h-12 object-cover rounded-lg"
                          />
                          <div>
                            <h3 className="text-white font-light">{prompt.title}</h3>
                            <p className="text-white/60 text-sm font-light">{prompt.subcategory}</p>
                            <span className={`${
                              prompt.status === 'published' 
                                ? 'bg-green-500/20 text-green-400' 
                                : 'bg-yellow-500/20 text-yellow-400'
                            } inline-block px-2 py-1 rounded text-xs font-light`}>
                              {prompt.status}
                            </span>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => togglePromptStatus(prompt.id, prompt.status)}
                            className={`${
                              prompt.status === 'published'
                                ? 'bg-yellow-500/20 text-yellow-400 hover:bg-yellow-500/30'
                                : 'bg-green-500/20 text-green-400 hover:bg-green-500/30'
                            } px-4 py-2 rounded-lg transition-all font-light text-sm`}
                          >
                            {prompt.status === 'published' ? 'Unpublish' : 'Publish'}
                          </button>
                          <button
                            onClick={() => handleDeletePrompt(prompt.id)}
                            className="px-4 py-2 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded-lg transition-all font-light text-sm"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    ))}

                    {prompts.length === 0 && (
                      <div className="text-center py-8 text-white/60 font-light">
                        No prompts uploaded yet.
                      </div>
                    )}
                  </div>
                )}
              </motion.div>
            )}

            {activeTab === 'categories' && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-light text-white">Manage Categories</h2>
                
                {/* Add Category Form */}
                <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6">
                  <h3 className="text-lg font-light text-white mb-4">Add New Category</h3>
                  <form onSubmit={handleAddCategory} className="flex space-x-3">
                    <input
                      type="text"
                      value={newCategory}
                      onChange={(e) => setNewCategory(e.target.value)}
                      placeholder="Category name..."
                      className="flex-1 bg-black/30 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-2 text-white placeholder-white/40 focus:outline-none focus:ring-2 focus:ring-red-500 focus:border-transparent font-light"
                    />
                    <button
                      type="submit"
                      className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-6 py-2 rounded-lg transition-all font-light"
                    >
                      Add
                    </button>
                  </form>
                </div>

                {/* Categories List */}
                <div className="grid gap-3">
                  {categories.map((category) => (
                    <div
                      key={category.id}
                      className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-4 flex items-center justify-between"
                    >
                      <div>
                        <span className="text-white font-light">{category.name}</span>
                        <span className="text-white/40 text-sm font-light ml-2">({category.slug})</span>
                      </div>
                      <button
                        onClick={() => handleDeleteCategory(category.id)}
                        className="px-3 py-1 bg-red-500/20 text-red-400 hover:bg-red-500/30 rounded text-sm font-light transition-all"
                      >
                        Delete
                      </button>
                    </div>
                  ))}

                  {categories.length === 0 && (
                    <div className="text-center py-4 text-white/60 font-light">
                      No custom categories added yet.
                    </div>
                  )}
                </div>
              </motion.div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}