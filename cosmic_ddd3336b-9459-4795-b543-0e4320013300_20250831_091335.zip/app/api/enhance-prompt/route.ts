import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY as string | undefined;
const GEMINI_API_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { prompt, previousPrompt, isRefine = false } = await request.json();
    
    if (!prompt?.trim()) {
      return NextResponse.json({ error: 'Prompt is required' }, { status: 400 });
    }

    // Check user's credit balance
    const userDoc = await db.collection('users').doc(user.uid).get();
    
    if (!userDoc.exists) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userData = userDoc.data();
    const currentCredits = userData?.credits || 0;

    if (currentCredits < 0.2) {
      return NextResponse.json({ error: 'Insufficient credits. Need at least 0.2 credits.' }, { status: 400 });
    }

    // Deduct 0.2 credits first
    await db.collection('users').doc(user.uid).update({
      credits: currentCredits - 0.2,
      updatedAt: db.FieldValue.serverTimestamp()
    });

    try {
      // Prepare the system prompt for Gemini
      const systemPrompt = `You are an expert AI prompt engineer specializing in cinematic influencer photography. Your task is to convert simple English descriptions into well-structured XML prompts optimized for AI image generation.

IMPORTANT REQUIREMENTS:
- Focus exclusively on influencer cinematic photography
- Optimize for 1:1 aspect ratio (square format)
- Ensure character consistency elements
- Include professional lighting setups
- Add brand-appropriate styling
- Output ONLY valid XML, no explanations

XML Structure Template:
<prompt>
  <subject_identity>[Detailed character description]</subject_identity>
  <style_reference>[Photography style and inspiration]</style_reference>
  <camera>
    <lens>[Specific lens type]</lens>
    <aperture>[f-stop value]</aperture>
    <iso>[ISO value]</iso>
    <shutter>[Shutter speed]</shutter>
  </camera>
  <lighting>
    <key>[Key light description]</key>
    <fill>[Fill light description]</fill>
    <rim>[Rim/hair light description]</rim>
  </lighting>
  <backdrop>[Background description]</backdrop>
  <wardrobe>[Clothing and styling]</wardrobe>
  <pose_and_gesture>[Specific pose instructions]</pose_and_gesture>
  <framing_and_composition>[Composition guidelines, include 1:1 aspect ratio]</framing_and_composition>
  <color_grade>[Color grading instructions]</color_grade>
  <mood>[Emotional tone and atmosphere]</mood>
  <story_context>[Narrative context]</story_context>
  <brand_feel>[Brand personality and values]</brand_feel>
  <consistency_guidelines>[Character consistency instructions]</consistency_guidelines>
  <negative_prompts>[What to avoid]</negative_prompts>
</prompt>

Make it professional, detailed, and optimized for influencer content creation.`;

      const userPrompt = isRefine && previousPrompt 
        ? `Please refine this existing XML prompt based on the new instructions: "${prompt}"

Existing prompt:
${previousPrompt}

Provide the improved XML version.`
        : `Convert this simple description into a professional XML prompt for cinematic influencer photography: "${prompt}"`;

      let enhancedPrompt = '';

      if (!GEMINI_API_KEY) {
        // Fallback: generate a structured XML locally if no external model key is set
        console.warn('Gemini API key not set. Using local fallback enhancer.');
        enhancedPrompt = generateFallbackXML(prompt, isRefine, previousPrompt);
      } else {
        // Call Gemini API
        const geminiResponse = await fetch(`${GEMINI_API_URL}?key=${GEMINI_API_KEY}`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `${systemPrompt}\n\n${userPrompt}`
                  }
                ]
              }
            ],
            generationConfig: {
              temperature: 0.7,
              topK: 40,
              topP: 0.95,
              maxOutputTokens: 1024,
            },
          }),
        });

        if (!geminiResponse.ok) {
          throw new Error(`Gemini API error: ${geminiResponse.status}`);
        }

        const geminiData = await geminiResponse.json();
        enhancedPrompt = geminiData?.candidates?.[0]?.content?.parts?.[0]?.text || '';
      }

      // Clean up the response - extract XML if wrapped in markdown
      if (enhancedPrompt.includes('```xml')) {
        const xmlMatch = enhancedPrompt.match(/```xml\s*([\s\S]*?)\s*```/);
        if (xmlMatch) {
          enhancedPrompt = xmlMatch[1].trim();
        }
      } else if (enhancedPrompt.includes('<prompt>')) {
        // Extract just the XML part if there's extra text
        const xmlMatch = enhancedPrompt.match(/<prompt>[\s\S]*<\/prompt>/);
        if (xmlMatch) {
          enhancedPrompt = xmlMatch[0];
        }
      } else if (!enhancedPrompt.trim()) {
        // As a safeguard, produce fallback XML if model returned nothing
        enhancedPrompt = generateFallbackXML(prompt, isRefine, previousPrompt);
      }

      // Generate JSON mirror
      const jsonOutput = xmlToJson(enhancedPrompt);

      // Log the enhancement usage
      await db.collection('enhancer_usage').add({
        userId: user.uid,
        inputPrompt: prompt,
        outputPrompt: enhancedPrompt,
        creditsSpent: 0.2,
        isRefine,
        success: true,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      // Create transaction record
      await db.collection('transactions').add({
        userId: user.uid,
        type: 'prompt_enhancement',
        amount: -0.2,
        description: isRefine ? 'Prompt refinement' : 'Prompt enhancement',
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      return NextResponse.json({
        enhancedPrompt,
        jsonOutput,
        creditsUsed: 0.2,
        remainingCredits: currentCredits - 0.2
      });

    } catch (apiError) {
      // Refund credits on API failure
      await db.collection('users').doc(user.uid).update({
        credits: currentCredits, // Refund the credits
        updatedAt: db.FieldValue.serverTimestamp()
      });

      // Log the failed attempt
      await db.collection('enhancer_usage').add({
        userId: user.uid,
        inputPrompt: prompt,
        creditsSpent: 0,
        isRefine,
        success: false,
        error: String(apiError),
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      throw apiError;
    }

  } catch (error) {
    console.error('Error enhancing prompt:', error);
    return NextResponse.json({ error: 'Enhancement failed. Please try again.' }, { status: 500 });
  }
}

// Helper function to convert XML to JSON
function xmlToJson(xml: string): string {
  try {
    // Simple XML to JSON converter for our specific structure
    const jsonObj: { [key: string]: string | object } = {};
    
    // Extract each XML tag and its content
    const tags = [
      'subject_identity', 'style_reference', 'backdrop', 'wardrobe', 
      'pose_and_gesture', 'framing_and_composition', 'color_grade', 
      'mood', 'story_context', 'brand_feel', 'consistency_guidelines', 
      'negative_prompts'
    ];
    
    tags.forEach(tag => {
      const regex = new RegExp(`<${tag}>(.*?)<\/${tag}>`, 's');
      const match = xml.match(regex);
      if (match) {
        jsonObj[tag] = match[1].trim();
      }
    });

    // Handle camera object
    const cameraMatch = xml.match(/<camera>([\s\S]*?)<\/camera>/);
    if (cameraMatch) {
      const cameraObj: { [key: string]: string } = {};
      const cameraContent = cameraMatch[1];
      
      ['lens', 'aperture', 'iso', 'shutter'].forEach(prop => {
        const propRegex = new RegExp(`<${prop}>(.*?)<\/${prop}>`, 's');
        const propMatch = cameraContent.match(propRegex);
        if (propMatch) {
          cameraObj[prop] = propMatch[1].trim();
        }
      });
      
      if (Object.keys(cameraObj).length > 0) {
        jsonObj.camera = cameraObj;
      }
    }

    // Handle lighting object
    const lightingMatch = xml.match(/<lighting>([\s\S]*?)<\/lighting>/);
    if (lightingMatch) {
      const lightingObj: { [key: string]: string } = {};
      const lightingContent = lightingMatch[1];
      
      ['key', 'fill', 'rim'].forEach(prop => {
        const propRegex = new RegExp(`<${prop}>(.*?)<\/${prop}>`, 's');
        const propMatch = lightingContent.match(propRegex);
        if (propMatch) {
          lightingObj[prop] = propMatch[1].trim();
        }
      });
      
      if (Object.keys(lightingObj).length > 0) {
        jsonObj.lighting = lightingObj;
      }
    }

    return JSON.stringify(jsonObj, null, 2);
  } catch (error) {
    console.error('Error converting XML to JSON:', error);
    return '{}';
  }
}

// Local fallback enhancer when external model is unavailable
function generateFallbackXML(prompt: string, isRefine: boolean, previousPrompt?: string): string {
  const base = (prompt || '').trim();
  const seed = base.slice(0, 120);
  const refinedNote = isRefine && previousPrompt ? 'Refined version based on prior XML and new instructions.' : 'Generated from description.';
  return `\n<prompt>\n  <subject_identity>${escapeXml(seed || 'influencer subject for cinematic portrait')}</subject_identity>\n  <style_reference>cinematic influencer photography, editorial quality, professional studio</style_reference>\n  <camera>\n    <lens>85mm prime portrait lens</lens>\n    <aperture>f/2.0</aperture>\n    <iso>200</iso>\n    <shutter>1/160</shutter>\n  </camera>\n  <lighting>\n    <key>soft key light with large octabox at 45°</key>\n    <fill>subtle fill from reflector opposite key</fill>\n    <rim>hair light for separation</rim>\n  </lighting>\n  <backdrop>minimal studio set, tasteful textures</backdrop>\n  <wardrobe>brand-appropriate, sleek and modern</wardrobe>\n  <pose_and_gesture>confident posture, natural expression</pose_and_gesture>\n  <framing_and_composition>centered composition, 1:1 aspect ratio, balanced negative space</framing_and_composition>\n  <color_grade>neutral cinematic grade with gentle contrast</color_grade>\n  <mood>confident, aspirational</mood>\n  <story_context>${refinedNote}</story_context>\n  <brand_feel>premium, modern, authentic</brand_feel>\n  <consistency_guidelines>maintain subject identity and style across shots</consistency_guidelines>\n  <negative_prompts>harsh shadows, overexposure, cluttered background</negative_prompts>\n</prompt>`;
}

function escapeXml(input: string): string {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}