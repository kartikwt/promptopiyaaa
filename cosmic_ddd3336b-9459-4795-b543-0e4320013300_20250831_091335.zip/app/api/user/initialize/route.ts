import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function POST() {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ message: 'Not authenticated' }, { status: 200 });
    }

    // Check if user already exists
    const userRef = db.collection('users').doc(user.uid);
    const userDoc = await userRef.get();

    // Determine signup bonus (check emailBonuses collection)
    let signupBonus = 20;
    if (user.email === ADMIN_EMAIL) signupBonus = 100;
    try {
      const bonusDoc = await db.collection('emailBonuses').doc(encodeURIComponent((user.email || '').toLowerCase())).get();
      if (bonusDoc.exists) {
        const data = bonusDoc.data();
        if (typeof data?.credits === 'number') {
          signupBonus = Math.max(signupBonus, data.credits as number);
        }
      }
    } catch {
      // ignore bonus read errors
    }
    
    if (!userDoc.exists) {
      // Create new user with signup bonus (ensure idempotent field)
      await userRef.set({
        email: user.email,
        displayName: user.displayName,
        credits: signupBonus,
        signupBonusApplied: true,
        isAdmin: user.uid === process.env.USER_ID || user.email === ADMIN_EMAIL, // Make project owner or specified email admin
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      // Log credit transaction
      await db.collection('transactions').add({
        userId: user.uid,
        type: 'signup_bonus',
        amount: signupBonus,
        description: 'New user signup bonus',
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      return NextResponse.json({ 
        message: `User initialized with ${signupBonus} free credits`,
        credits: signupBonus 
      });
    }

    // If the user doc already exists (e.g., auto-created by auth provider), ensure bonus has been applied idempotently
    const existingData = userDoc.data() as Record<string, unknown> | undefined;
    const currentCredits = typeof existingData?.credits === 'number' ? (existingData?.credits as number) : 0;
    const alreadyApplied = existingData?.signupBonusApplied === true;

    // Ensure special email has at least 100 credits
    if (user.email === ADMIN_EMAIL && (currentCredits < 100)) {
      const diff = 100 - currentCredits;
      await userRef.update({
        credits: 100,
        signupBonusApplied: true,
        updatedAt: db.FieldValue.serverTimestamp()
      });
      await db.collection('transactions').add({
        userId: user.uid,
        type: alreadyApplied ? 'admin_bonus_adjust' : 'signup_bonus',
        amount: diff,
        description: 'Admin email ensured to have 100 credits',
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });
      return NextResponse.json({ message: 'Credits adjusted to 100 for special email', credits: 100 });
    }

    if (!alreadyApplied) {
      const newCredits = Math.max(currentCredits, signupBonus);
      const diff = newCredits - currentCredits;
      await userRef.update({
        credits: newCredits,
        signupBonusApplied: true,
        updatedAt: db.FieldValue.serverTimestamp()
      });
      if (diff > 0) {
        await db.collection('transactions').add({
          userId: user.uid,
          type: 'signup_bonus',
          amount: diff,
          description: 'Signup bonus applied to existing user document',
          createdAt: db.FieldValue.serverTimestamp(),
          updatedAt: db.FieldValue.serverTimestamp()
        });
      }
      return NextResponse.json({ message: diff > 0 ? `Signup bonus applied: +${diff} credits` : 'Signup bonus recorded', credits: newCredits });
    }

    return NextResponse.json({ message: 'User already initialized' });

  } catch (error) {
    console.error('Error initializing user:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}