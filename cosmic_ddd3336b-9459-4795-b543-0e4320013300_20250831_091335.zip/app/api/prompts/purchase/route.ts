import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.COSMICAUTH_SECRET as string;

// Demo PDF content for prompts
const demoPDFContent = {
  'demo-cinematic-portrait-1': `# Fashion Influencer Studio Portrait - Professional Prompt

## XML Prompt Structure:
\`\`\`xml
<prompt>
  <subject_identity>Fashion influencer, confident pose, professional model stance</subject_identity>
  <style_reference>High-end fashion photography, editorial style, Vogue aesthetic</style_reference>
  <camera>
    <lens>85mm portrait lens</lens>
    <aperture>f/2.8</aperture>
    <iso>400</iso>
    <shutter>1/125s</shutter>
  </camera>
  <lighting>
    <key>Softbox key light at 45-degree angle</key>
    <fill>Large reflector for shadow fill</fill>
    <rim>Hair light from behind for separation</rim>
  </lighting>
  <backdrop>Seamless white backdrop, professional studio</backdrop>
  <wardrobe>Elegant designer clothing, contemporary fashion</wardrobe>
  <pose_and_gesture>Confident stance, engaging eye contact with camera</pose_and_gesture>
  <framing_and_composition>Portrait orientation, rule of thirds, 1:1 aspect ratio</framing_and_composition>
  <color_grade>Clean, professional color grading with slight warmth</color_grade>
  <mood>Professional, confident, aspirational</mood>
  <story_context>Successful fashion influencer in professional studio</story_context>
  <brand_feel>Luxury, professional, aspirational lifestyle</brand_feel>
  <consistency_guidelines>Maintain same lighting setup, pose variations allowed</consistency_guidelines>
  <negative_prompts>amateur lighting, harsh shadows, busy background, poor composition</negative_prompts>
</prompt>
\`\`\`

## Usage Instructions:
1. Use this XML structure with your AI image generator
2. Maintain the same lighting setup for consistency
3. Vary poses while keeping the professional aesthetic
4. Perfect for brand collaboration content

## Character Consistency Tips:
- Save the generated face and use as reference
- Use consistent lighting angle and intensity
- Maintain the same wardrobe style across shots
- Keep the same backdrop for series consistency`,

  'demo-fashion-shoot-1': `# Urban Street Style Campaign - Professional Prompt

## XML Prompt Structure:
\`\`\`xml
<prompt>
  <subject_identity>Street style influencer, urban fashion, contemporary style</subject_identity>
  <style_reference>Street photography aesthetic, editorial urban fashion</style_reference>
  <camera>
    <lens>35mm wide-angle lens</lens>
    <aperture>f/4</aperture>
    <iso>800</iso>
    <shutter>1/250s</shutter>
  </camera>
  <lighting>
    <key>Natural street lighting, golden hour preferred</key>
    <fill>Urban environment reflective fill</fill>
    <rim>Natural backlighting from street sources</rim>
  </lighting>
  <backdrop>Urban street environment, modern architecture</backdrop>
  <wardrobe>Contemporary street fashion, designer casual wear</wardrobe>
  <pose_and_gesture>Natural walking pose, candid movement</pose_and_gesture>
  <framing_and_composition>Dynamic angles, rule of thirds, urban context</framing_and_composition>
  <color_grade>Urban cinematic grade, enhanced contrast</color_grade>
  <mood>Confident, edgy, contemporary urban</mood>
  <story_context>Fashion influencer in natural urban environment</story_context>
  <brand_feel>Edgy, contemporary, street-smart luxury</brand_feel>
  <consistency_guidelines>Same urban location, consistent styling</consistency_guidelines>
  <negative_prompts>amateur composition, poor lighting, cluttered background</negative_prompts>
</prompt>
\`\`\`

Perfect for lifestyle brands and street fashion content.`,

  'demo-studio-1': `# Minimalist Studio Aesthetic - Professional Prompt

## XML Prompt Structure:
\`\`\`xml
<prompt>
  <subject_identity>Minimalist fashion influencer, clean aesthetic</subject_identity>
  <style_reference>Minimalist fashion photography, clean lines</style_reference>
  <camera>
    <lens>50mm standard lens</lens>
    <aperture>f/5.6</aperture>
    <iso>200</iso>
    <shutter>1/160s</shutter>
  </camera>
  <lighting>
    <key>Large softbox for even illumination</key>
    <fill>White backdrop reflection</fill>
    <rim>Subtle rim light for definition</rim>
  </lighting>
  <backdrop>Pure white seamless background</backdrop>
  <wardrobe>Minimalist clothing, clean lines, neutral colors</wardrobe>
  <pose_and_gesture>Clean, geometric poses, minimal movement</pose_and_gesture>
  <framing_and_composition>Centered composition, negative space, 1:1 aspect</framing_and_composition>
  <color_grade>Clean, neutral tones, high contrast</color_grade>
  <mood>Serene, professional, sophisticated</mood>
  <story_context>Luxury minimalist brand aesthetic</story_context>
  <brand_feel>Premium, clean, sophisticated simplicity</brand_feel>
  <consistency_guidelines>Maintain white backdrop, minimal styling</consistency_guidelines>
  <negative_prompts>cluttered composition, busy patterns, harsh lighting</negative_prompts>
</prompt>
\`\`\`

Perfect for premium beauty and lifestyle brands.`,

  'demo-celebrity-1': `# Celebrity Red Carpet Style - Professional Prompt

## XML Prompt Structure:
\`\`\`xml
<prompt>
  <subject_identity>Glamorous celebrity-style influencer, red carpet elegance</subject_identity>
  <style_reference>Hollywood glamour photography, A-list celebrity aesthetic</style_reference>
  <camera>
    <lens>85mm portrait lens</lens>
    <aperture>f/2.0</aperture>
    <iso>400</iso>
    <shutter>1/200s</shutter>
  </camera>
  <lighting>
    <key>Professional beauty dish for glamour lighting</key>
    <fill>Large silk reflector for soft shadows</fill>
    <rim>Multiple hair lights for dramatic separation</rim>
  </lighting>
  <backdrop>Luxury event backdrop or velvet draping</backdrop>
  <wardrobe>High-end designer evening wear, luxury accessories</wardrobe>
  <pose_and_gesture>Confident red carpet poses, elegant hand placement</pose_and_gesture>
  <framing_and_composition>Classic portrait framing, emphasis on elegance</framing_and_composition>
  <color_grade>Rich, saturated colors with golden highlights</color_grade>
  <mood>Glamorous, confident, luxury lifestyle</mood>
  <story_context>A-list celebrity at premium event</story_context>
  <brand_feel>Ultimate luxury, exclusivity, aspiration</brand_feel>
  <consistency_guidelines>Maintain glamour lighting, luxury styling</consistency_guidelines>
  <negative_prompts>casual clothing, poor lighting, amateur composition</negative_prompts>
</prompt>
\`\`\`

Perfect for luxury brands and high-end collaborations.`,

  'demo-art-1': `# Artistic Cinematic Vision - Professional Prompt

## XML Prompt Structure:
\`\`\`xml
<prompt>
  <subject_identity>Artistic influencer, creative and expressive</subject_identity>
  <style_reference>Fine art photography meets fashion, editorial artistic style</style_reference>
  <camera>
    <lens>50mm prime lens</lens>
    <aperture>f/2.8</aperture>
    <iso>400</iso>
    <shutter>1/125s</shutter>
  </camera>
  <lighting>
    <key>Dramatic window light or single directional source</key>
    <fill>Minimal fill to maintain mood</fill>
    <rim>Natural or subtle rim lighting</rim>
  </lighting>
  <backdrop>Artistic environment, textured walls or natural settings</backdrop>
  <wardrobe>Creative, artistic clothing with interesting textures</wardrobe>
  <pose_and_gesture>Expressive poses, storytelling through body language</pose_and_gesture>
  <framing_and_composition>Creative composition, rule of thirds, artistic framing</framing_and_composition>
  <color_grade>Artistic color grading, enhanced mood and atmosphere</color_grade>
  <mood>Creative, expressive, emotionally engaging</mood>
  <story_context>Artist or creative professional in inspiring environment</story_context>
  <brand_feel>Creative, authentic, artistically sophisticated</brand_feel>
  <consistency_guidelines>Maintain artistic lighting and creative composition</consistency_guidelines>
  <negative_prompts>commercial look, overly posed, harsh lighting</negative_prompts>
</prompt>
\`\`\`

Perfect for creative brands and artistic collaborations.`
};

export async function POST(request: Request) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    const { promptId } = await request.json();
    
    if (!promptId) {
      return NextResponse.json({ error: 'Prompt ID required' }, { status: 400 });
    }

    // Check user's credit balance
    const userDoc = await db.collection('users').doc(user.uid).get();
    
    if (!userDoc.exists) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    const userData = userDoc.data();
    const currentCredits = userData?.credits || 0;

    // Check if user has already purchased this prompt (single-field key)
    const userPromptKey = `${user.uid}_${promptId}`;
    const existingPurchaseSnap = await db.collection('purchases')
      .where('userPromptKey', '==', userPromptKey)
      .get();

    let downloadPath: string | null = null;
    let promptTitle = 'Unknown Prompt';

    // Get the prompt to determine file source
    const promptDoc = await db.collection('prompts').doc(promptId).get();
    if (promptDoc.exists && promptDoc.data()?.pdfUrl) {
      const promptData = promptDoc.data();
      downloadPath = promptData?.pdfUrl;
      promptTitle = promptData?.title || 'Prompt';
    }

    if (existingPurchaseSnap.empty) {
      // New purchase
      if (currentCredits < 1) {
        return NextResponse.json({ error: 'Insufficient credits' }, { status: 400 });
      }

      const batch = db.batch();
      // Deduct credit from user
      batch.update(db.collection('users').doc(user.uid), {
        credits: currentCredits - 1,
        updatedAt: db.FieldValue.serverTimestamp()
      });

      // Create purchase record with single-field key
      const purchaseRef = db.collection('purchases').doc();
      batch.set(purchaseRef, {
        userId: user.uid,
        promptId: promptId,
        userPromptKey,
        price: 1,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      // Create transaction record
      const transactionRef = db.collection('transactions').doc();
      batch.set(transactionRef, {
        userId: user.uid,
        type: 'prompt_purchase',
        amount: -1,
        promptId: promptId,
        description: `Purchased prompt: ${promptId}`,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

      await batch.commit();
    }

    // Build a signed download link via our proxy route (24h expiry)
    const token = jwt.sign({ uid: user.uid, promptId }, JWT_SECRET, { expiresIn: '24h' });
    const relativeDownloadPath = `/api/prompts/download?promptId=${encodeURIComponent(promptId)}&token=${encodeURIComponent(token)}`;

    // If demo prompt, fallback to base64 plain content
    if (!downloadPath) {
      const pdfContent = demoPDFContent[promptId as keyof typeof demoPDFContent] || 'Prompt content not available';
      const dataUrl = `data:text/plain;base64,${Buffer.from(pdfContent).toString('base64')}`;
      return NextResponse.json({ 
        success: true,
        downloadUrl: dataUrl,
        promptTitle,
        message: 'Prompt purchased successfully'
      });
    }

    return NextResponse.json({ 
      success: true,
      downloadUrl: relativeDownloadPath,
      promptTitle,
      message: 'Prompt purchased successfully'
    });

  } catch (error) {
    console.error('Error processing purchase:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}