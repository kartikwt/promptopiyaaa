import { NextResponse } from 'next/server';
import jwt from 'jsonwebtoken';
import { db } from 'cosmic-database';

const JWT_SECRET = process.env.COSMICAUTH_SECRET as string;

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const promptId = searchParams.get('promptId');
    const token = searchParams.get('token');

    if (!promptId || !token) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 });
    }

    let payload: { uid: string; promptId: string };
    try {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      payload = jwt.verify(token, JWT_SECRET) as any;
    } catch {
      return NextResponse.json({ error: 'Invalid or expired link' }, { status: 401 });
    }

    if (payload.promptId !== promptId) {
      return NextResponse.json({ error: 'Token mismatch' }, { status: 401 });
    }

    // Enforce ownership: user must have a purchase record for this prompt
    const key = `${payload.uid}_${promptId}`;
    const purchaseSnap = await db
      .collection('purchases')
      .where('userPromptKey', '==', key)
      .limit(1)
      .get();
    if (purchaseSnap.empty) {
      return NextResponse.json({ error: 'Not authorized to download' }, { status: 403 });
    }

    // Fetch prompt to get pdf url
    const doc = await db.collection('prompts').doc(promptId).get();
    if (!doc.exists) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 });
    }
    const data = doc.data();
    const pdfUrl = data?.pdfUrl as string | undefined;
    const title = (data?.title as string | undefined) || 'prompt';

    if (!pdfUrl) {
      return NextResponse.json({ error: 'File not available' }, { status: 404 });
    }

    const res = await fetch(pdfUrl);
    if (!res.ok) {
      return NextResponse.json({ error: 'Failed to fetch file' }, { status: 502 });
    }

    const blob = await res.blob();
    const headers = new Headers();
    headers.set('Content-Type', blob.type || 'application/pdf');
    headers.set('Content-Disposition', `attachment; filename="${title.replace(/[^a-z0-9-_\. ]/gi, '_')}.pdf"`);

    return new NextResponse(blob.stream(), { status: 200, headers });
  } catch (e) {
    console.error('Download error', e);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}