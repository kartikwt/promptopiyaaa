import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';

// Demo prompts data - this will be replaced by database queries once admin uploads products
const demoPrompts = [
  {
    id: 'demo-cinematic-portrait-1',
    title: 'Fashion Influencer Studio Portrait',
    description: 'Professional studio lighting setup for fashion influencer content. Perfect for brand collaborations and portfolio shots.',
    subcategory: 'Cinematic Portrait',
    thumbnailUrl: 'https://images.unsplash.com/photo-1578664865136-74b450f31cd9',
    price: 1,
    isDemo: true
  },
  {
    id: 'demo-fashion-shoot-1',
    title: 'Urban Street Style Campaign',
    description: 'Edgy street photography style perfect for fashion brands and lifestyle content creation.',
    subcategory: 'Fashion Shoot',
    thumbnailUrl: 'https://images.unsplash.com/photo-1591729259517-e2d0553fd4ec',
    price: 1,
    isDemo: true
  },
  {
    id: 'demo-studio-1',
    title: 'Minimalist Studio Aesthetic',
    description: 'Clean, professional studio setup with dramatic shadows and professional lighting.',
    subcategory: 'Studio',
    thumbnailUrl: 'https://images.unsplash.com/photo-1528363088237-2e212bcd4e19',
    price: 1,
    isDemo: true
  },
  {
    id: 'demo-celebrity-1',
    title: 'Celebrity Red Carpet Style',
    description: 'Glamorous lighting and posing techniques inspired by A-list celebrity photography.',
    subcategory: 'With Celebrity',
    thumbnailUrl: 'https://images.unsplash.com/photo-1565589382975-06d2bd00e7f8',
    price: 1,
    isDemo: true
  },
  {
    id: 'demo-art-1',
    title: 'Artistic Cinematic Vision',
    description: 'Fine art approach to influencer photography with dramatic composition and storytelling.',
    subcategory: 'Art',
    thumbnailUrl: 'https://images.unsplash.com/photo-1591805694380-df1617fe80b6',
    price: 1,
    isDemo: true
  }
];

export async function GET() {
  try {
    // First try to get prompts from database
    const snapshot = await db.collection('prompts')
      .where('status', '==', 'published')
      .get();

    let prompts = [];

    if (!snapshot.empty) {
      // Use database prompts if available
      const items: Array<{ id: string; title: string; description: string; subcategory: string; thumbnailUrl: string; price: number; _createdAt: number }> = [];
      snapshot.forEach(doc => {
        const data = doc.data();
        const createdAt = (data && (data as { createdAt?: { toMillis?: () => number } }).createdAt && typeof (data as { createdAt?: { toMillis?: () => number } }).createdAt?.toMillis === 'function')
          ? (data as { createdAt: { toMillis: () => number } }).createdAt.toMillis()
          : 0;
        items.push({
          id: doc.id,
          title: data.title,
          description: data.description,
          subcategory: data.subcategory,
          thumbnailUrl: data.thumbnailUrl,
          price: data.price || 1,
          _createdAt: createdAt
        });
      });
      items.sort((a, b) => (b._createdAt || 0) - (a._createdAt || 0));
      prompts = items.map(({ id, title, description, subcategory, thumbnailUrl, price }) => ({
        id,
        title,
        description,
        subcategory,
        thumbnailUrl,
        price
      }));
    } else {
      // Use demo prompts if no database prompts available
      prompts = demoPrompts;
    }

    return NextResponse.json({ prompts });

  } catch (error) {
    console.error('Error fetching prompts:', error);
    // Fallback to demo prompts on error
    return NextResponse.json({ prompts: demoPrompts });
  }
}