import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import jwt from 'jsonwebtoken';
import { db } from 'cosmic-database';

const JWT_SECRET = process.env.COSMICAUTH_SECRET as string;

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) return NextResponse.json({ error: 'Authentication required' }, { status: 401 });

    const { searchParams } = new URL(request.url);
    const promptId = searchParams.get('promptId');
    if (!promptId) return NextResponse.json({ error: 'Prompt ID required' }, { status: 400 });

    // Verify ownership before issuing a download link
    const key = `${user.uid}_${promptId}`;
    const snap = await db.collection('purchases').where('userPromptKey', '==', key).limit(1).get();
    if (snap.empty) {
      return NextResponse.json({ error: 'Not authorized' }, { status: 403 });
    }

    const token = jwt.sign({ uid: user.uid, promptId }, JWT_SECRET, { expiresIn: '24h' });
    // Return a same-origin relative URL to avoid localhost cases
    const url = `/api/prompts/download?promptId=${encodeURIComponent(promptId)}&token=${encodeURIComponent(token)}`;
    return NextResponse.json({ url });
  } catch (e) {
    console.error('Generate link error', e);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}