import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get('id');
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 });

    const doc = await db.collection('prompts').doc(id).get();
    if (!doc.exists) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    const data = doc.data();

    // Only expose published prompts to unauthenticated users
    if (data?.status !== 'published') {
      // Check admin session
      const user = await getServerSession();
      if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    }

    const result = {
      id: doc.id,
      title: data?.title,
      description: data?.description,
      subcategory: data?.subcategory,
      thumbnailUrl: data?.thumbnailUrl,
      thumbnailUrls: data?.thumbnailUrls || (data?.thumbnailUrl ? [data.thumbnailUrl] : []),
      price: data?.price || 1,
      status: data?.status,
    };

    return NextResponse.json(result);
  } catch (e) {
    console.error('Get prompt error', e);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
