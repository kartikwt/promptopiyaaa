import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const categoryId = params.id;

    // Check if category exists
    const categoryDoc = await db.collection('categories').doc(categoryId).get();
    
    if (!categoryDoc.exists) {
      return NextResponse.json({ error: 'Category not found' }, { status: 404 });
    }

    // Check if any prompts are using this category
    const categoryData = categoryDoc.data();
    const promptsUsingCategory = await db.collection('prompts')
      .where('subcategory', '==', categoryData?.name)
      .get();

    if (!promptsUsingCategory.empty) {
      return NextResponse.json({ 
        error: `Cannot delete category. ${promptsUsingCategory.size} prompt(s) are using this category.` 
      }, { status: 400 });
    }

    // Delete category
    await db.collection('categories').doc(categoryId).delete();

    return NextResponse.json({ 
      success: true, 
      message: 'Category deleted successfully' 
    });

  } catch (error) {
    console.error('Error deleting category:', error);
    return NextResponse.json({ error: 'Category deletion failed' }, { status: 500 });
  }
}