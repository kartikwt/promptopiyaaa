import { NextResponse } from 'next/server';
import { db } from 'cosmic-database';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const email = searchParams.get('email');
    const creditsParam = searchParams.get('credits');
    const key = searchParams.get('key');

    if (!email || !creditsParam) {
      return NextResponse.json({ error: 'Missing email or credits' }, { status: 400 });
    }
    const credits = Number(creditsParam);
    if (!Number.isFinite(credits) || credits < 0) {
      return NextResponse.json({ error: 'Invalid credits' }, { status: 400 });
    }

    // Simple auth gate using project owner id
    if (!key || key !== process.env.USER_ID) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Try to find existing user by email
    const snap = await db.collection('users').where('email', '==', email).limit(1).get();
    if (!snap.empty) {
      const doc = snap.docs[0];
      await doc.ref.update({ credits, updatedAt: db.FieldValue.serverTimestamp() });
      return NextResponse.json({ success: true, updatedUserId: doc.id, credits });
    }

    // If no user yet, store a bonus to be applied on signup/first init
    await db.collection('emailBonuses')
      .doc(encodeURIComponent(email.toLowerCase()))
      .set({
        email,
        credits,
        createdAt: db.FieldValue.serverTimestamp(),
        updatedAt: db.FieldValue.serverTimestamp()
      });

    return NextResponse.json({ success: true, pendingBonus: true, email, credits });
  } catch (error) {
    console.error('Error granting bonus:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
