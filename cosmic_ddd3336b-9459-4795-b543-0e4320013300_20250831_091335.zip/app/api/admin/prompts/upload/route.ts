import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const COSMIC_FILES_API_KEY = process.env.COSMIC_FILES_SECRET;
const USER_ID = process.env.USER_ID;
const PROJECT_ID = process.env.NEXT_PUBLIC_CLIENT_ID;
const FILES_BASE_URL = 'https://files.cosmic.new';
const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function POST(request: NextRequest) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const formData = await request.formData();
    const title = formData.get('title') as string;
    const description = formData.get('description') as string;
    const subcategory = formData.get('subcategory') as string;
    const status = (formData.get('status') as string) || 'published';
    const thumbnails = formData.getAll('thumbnails') as File[];
    const pdf = formData.get('pdf') as File;

    if (!title || !description || !subcategory || thumbnails.length === 0 || !pdf) {
      return NextResponse.json({ error: 'All fields are required' }, { status: 400 });
    }

    if (thumbnails.length < 1 || thumbnails.length > 2) {
      return NextResponse.json({ error: 'Please upload 1–2 thumbnails' }, { status: 400 });
    }

    // Validate thumbnails are images (allow empty type from some browsers by checking name as fallback)
    for (const t of thumbnails) {
      const tName = (t as unknown as { name?: string }).name || '';
      const looksImageByExt = /\.(png|jpg|jpeg|webp|gif)$/i.test(tName);
      if (!(t.type && t.type.startsWith('image/')) && !looksImageByExt) {
        return NextResponse.json({ error: 'Thumbnails must be image files (png/jpg/webp)' }, { status: 400 });
      }
    }

    // Validate PDF (allow empty type or octet-stream; fallback to name extension)
    const pdfName = (pdf as unknown as { name?: string }).name || '';
    const pdfTypeOk = pdf.type === 'application/pdf' || pdf.type === 'application/octet-stream' || /\.pdf$/i.test(pdfName);
    if (!pdfTypeOk) {
      return NextResponse.json({ error: 'PDF file must be in .pdf format' }, { status: 400 });
    }

    // Upload thumbnails to Cosmic Files
    const uploadedThumbs: { fileId: string; url: string }[] = [];
    for (const t of thumbnails) {
      const tForm = new FormData();
      tForm.append('userId', USER_ID!);
      tForm.append('projectId', PROJECT_ID!);
      tForm.append('creatorId', user.uid);
      tForm.append('file', t);

      const tRes = await fetch(`${FILES_BASE_URL}/files/upload`, {
        method: 'POST',
        headers: { 'X-API-Key': COSMIC_FILES_API_KEY! },
        body: tForm,
      });
      if (!tRes.ok) {
        const txt = await tRes.text().catch(() => '');
        throw new Error(`Failed to upload thumbnail (${tRes.status}). ${txt}`);
      }
      const tData = await tRes.json();
      uploadedThumbs.push({
        fileId: tData.fileId,
        url: `${FILES_BASE_URL}/files/${USER_ID}/${PROJECT_ID}?fileId=${tData.fileId}`
      });
    }

    // Upload PDF to Cosmic Files
    const pdfFormData = new FormData();
    pdfFormData.append('userId', USER_ID!);
    pdfFormData.append('projectId', PROJECT_ID!);
    pdfFormData.append('creatorId', user.uid);
    pdfFormData.append('file', pdf);

    const pdfResponse = await fetch(`${FILES_BASE_URL}/files/upload`, {
      method: 'POST',
      headers: {
        'X-API-Key': COSMIC_FILES_API_KEY!,
      },
      body: pdfFormData,
    });

    if (!pdfResponse.ok) {
      // Clean up thumbnails if PDF upload fails
      await Promise.all(
        uploadedThumbs.map((th) =>
          fetch(`${FILES_BASE_URL}/files/${USER_ID}/${PROJECT_ID}/${th.fileId}`, {
            method: 'DELETE',
            headers: { 'X-API-Key': COSMIC_FILES_API_KEY! },
          })
        )
      );
      const txt = await pdfResponse.text().catch(() => '');
      throw new Error(`Failed to upload PDF (${pdfResponse.status}). ${txt}`);
    }

    const pdfData = await pdfResponse.json();

    // Save prompt to database
    const promptData = {
      title,
      description,
      subcategory,
      thumbnailUrl: uploadedThumbs[0].url,
      thumbnailFileId: uploadedThumbs[0].fileId,
      thumbnailUrls: uploadedThumbs.map((t) => t.url),
      thumbnailFileIds: uploadedThumbs.map((t) => t.fileId),
      pdfUrl: `${FILES_BASE_URL}/files/${USER_ID}/${PROJECT_ID}?fileId=${pdfData.fileId}`,
      pdfFileId: pdfData.fileId,
      status: status === 'draft' ? 'draft' : 'published',
      price: 1, // Fixed price of 1 credit
      createdBy: user.uid,
      createdAt: db.FieldValue.serverTimestamp(),
      updatedAt: db.FieldValue.serverTimestamp(),
    };

    const promptRef = await db.collection('prompts').add(promptData);

    return NextResponse.json({
      success: true,
      promptId: promptRef.id,
      message: 'Prompt uploaded successfully'
    });

  } catch (error) {
    console.error('Error uploading prompt:', error);
    const message = (error as Error)?.message || 'Upload failed';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}