import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const COSMIC_FILES_API_KEY = process.env.COSMIC_FILES_SECRET;
const USER_ID = process.env.USER_ID;
const PROJECT_ID = process.env.NEXT_PUBLIC_CLIENT_ID;
const FILES_BASE_URL = 'https://files.cosmic.new';
const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const promptId = params.id;

    // Get prompt data first to get file IDs
    const promptDoc = await db.collection('prompts').doc(promptId).get();
    
    if (!promptDoc.exists) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 });
    }

    const promptData = promptDoc.data();

    // Delete files from Cosmic Files if they exist
    if (promptData?.thumbnailFileId) {
      try {
        await fetch(`${FILES_BASE_URL}/files/${USER_ID}/${PROJECT_ID}/${promptData.thumbnailFileId}`, {
          method: 'DELETE',
          headers: {
            'X-API-Key': COSMIC_FILES_API_KEY!,
          },
        });
      } catch (error) {
        console.error('Error deleting thumbnail file:', error);
        // Continue with prompt deletion even if file deletion fails
      }
    }

    if (promptData?.pdfFileId) {
      try {
        await fetch(`${FILES_BASE_URL}/files/${USER_ID}/${PROJECT_ID}/${promptData.pdfFileId}`, {
          method: 'DELETE',
          headers: {
            'X-API-Key': COSMIC_FILES_API_KEY!,
          },
        });
      } catch (error) {
        console.error('Error deleting PDF file:', error);
        // Continue with prompt deletion even if file deletion fails
      }
    }

    // Delete prompt from database
    await db.collection('prompts').doc(promptId).delete();

    return NextResponse.json({ 
      success: true, 
      message: 'Prompt deleted successfully' 
    });

  } catch (error) {
    console.error('Error deleting prompt:', error);
    return NextResponse.json({ error: 'Delete failed' }, { status: 500 });
  }
}