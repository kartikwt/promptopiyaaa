import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function PATCH(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    const promptId = params.id;
    const { status } = await request.json();

    if (!status || !['draft', 'published'].includes(status)) {
      return NextResponse.json({ error: 'Invalid status. Must be "draft" or "published"' }, { status: 400 });
    }

    // Check if prompt exists
    const promptDoc = await db.collection('prompts').doc(promptId).get();
    
    if (!promptDoc.exists) {
      return NextResponse.json({ error: 'Prompt not found' }, { status: 404 });
    }

    // Update prompt status
    await db.collection('prompts').doc(promptId).update({
      status,
      updatedAt: db.FieldValue.serverTimestamp(),
    });

    return NextResponse.json({ 
      success: true, 
      message: `Prompt ${status === 'published' ? 'published' : 'unpublished'} successfully` 
    });

  } catch (error) {
    console.error('Error updating prompt status:', error);
    return NextResponse.json({ error: 'Status update failed' }, { status: 500 });
  }
}