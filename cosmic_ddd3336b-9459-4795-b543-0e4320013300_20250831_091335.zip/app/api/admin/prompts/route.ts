import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function GET() {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get all prompts (including drafts) for admin
    const snapshot = await db.collection('prompts')
      .orderBy('createdAt', 'desc')
      .get();

    const prompts: {
      id: string;
      title: string;
      description: string;
      subcategory: string;
      thumbnailUrl: string;
      pdfUrl?: string;
      status: string;
      createdAt: string;
    }[] = [];
    
    snapshot.forEach(doc => {
      const data = doc.data();
      prompts.push({
        id: doc.id,
        title: data.title,
        description: data.description,
        subcategory: data.subcategory,
        thumbnailUrl: data.thumbnailUrl,
        pdfUrl: data.pdfUrl,
        status: data.status || 'draft',
        createdAt: data.createdAt?.toDate?.()?.toISOString() || new Date().toISOString()
      });
    });

    return NextResponse.json({ prompts });

  } catch (error) {
    console.error('Error fetching admin prompts:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}