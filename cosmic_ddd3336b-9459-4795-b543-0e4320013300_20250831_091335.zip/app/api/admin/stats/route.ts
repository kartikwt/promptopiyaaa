import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

const ADMIN_EMAIL = 'kumawatkartikey361@gmail.com';

export async function GET() {
  try {
    const user = await getServerSession();
    
    if (!user) {
      return NextResponse.json({ error: 'Authentication required' }, { status: 401 });
    }

    // Check if user is admin
    const userDoc = await db.collection('users').doc(user.uid).get();
    const userData = userDoc.data();
    
    if (!userData?.isAdmin && user.email !== ADMIN_EMAIL) {
      return NextResponse.json({ error: 'Admin access required' }, { status: 403 });
    }

    // Get stats in parallel
    const [
      promptsSnapshot,
      purchasesSnapshot,
      enhancementsSnapshot,
      transactionsSnapshot
    ] = await Promise.all([
      db.collection('prompts').get(),
      db.collection('purchases').get(),
      db.collection('enhancer_usage').get(),
      db.collection('transactions').where('type', '==', 'prompt_purchase').get()
    ]);

    // Calculate stats
    const totalPrompts = promptsSnapshot.size;
    const totalPurchases = purchasesSnapshot.size;
    const totalEnhancements = enhancementsSnapshot.size;

    // Calculate total credits earned from prompt purchases
    let totalCreditsEarned = 0;
    transactionsSnapshot.forEach(doc => {
      const data = doc.data();
      // Since purchases deduct credits (negative amount), we make it positive for earnings
      totalCreditsEarned += Math.abs(data.amount || 0);
    });

    return NextResponse.json({
      totalPrompts,
      totalPurchases,
      totalCreditsEarned,
      totalEnhancements
    });

  } catch (error) {
    console.error('Error fetching admin stats:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}