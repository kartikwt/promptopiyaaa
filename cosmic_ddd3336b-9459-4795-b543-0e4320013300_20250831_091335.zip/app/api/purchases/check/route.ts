import { NextResponse } from 'next/server';
import { getServerSession } from 'cosmic-authentication';
import { db } from 'cosmic-database';

export async function GET(request: Request) {
  try {
    const user = await getServerSession();
    if (!user) {
      return NextResponse.json({ owned: false }, { status: 200 });
    }

    const { searchParams } = new URL(request.url);
    const promptId = searchParams.get('promptId');
    if (!promptId) {
      return NextResponse.json({ error: 'Prompt ID required' }, { status: 400 });
    }

    const key = `${user.uid}_${promptId}`;
    const snap = await db.collection('purchases').where('userPromptKey', '==', key).get();
    return NextResponse.json({ owned: !snap.empty });
  } catch (e) {
    console.error('Ownership check error', e);
    return NextResponse.json({ owned: false }, { status: 200 });
  }
}
