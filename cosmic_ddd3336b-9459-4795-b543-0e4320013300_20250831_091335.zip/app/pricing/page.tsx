'use client';

import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import { Icon } from '@iconify/react';
import { useAuth } from 'cosmic-authentication';
import { useCosmicPayments, type CosmicProduct } from 'cosmic-payments/client';
import Navigation from '@/app/components/Navigation';

export default function PricingPage() {
  const { isAuthenticated, signIn } = useAuth();
  const { getProducts, checkout, loading } = useCosmicPayments();
  const [products, setProducts] = useState<CosmicProduct[] | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const init = async () => {
      try {
        const result = await getProducts('all');
        if (result) setProducts(result);
      } catch {
        setError('Failed to load products');
      }
    };
    void init();
  }, [getProducts]);

  const unlimited = useMemo(() => {
    if (!products || products.length === 0) return null;
    const found = products.find((p) => p.name.toLowerCase().includes('unlimited')) || products[0];
    const firstActivePrice = found.prices.find((pr) => pr.active) || found.prices[0];
    return firstActivePrice ? { product: found, priceId: firstActivePrice.price_id } : null;
  }, [products]);

  const handleCheckout = async () => {
    if (!isAuthenticated) {
      signIn();
      return;
    }
    if (!unlimited) return;
    try {
      await checkout({
        priceId: unlimited.priceId,
        productId: unlimited.product.product_id,
        successPath: '/payments/success',
        cancelPath: '/pricing',
      });
    } catch {
      setError('Checkout failed');
    }
  };

  return (
    <div className="min-h-screen">
      {/* Background */}
      <div 
        className="fixed inset-0 z-0" 
        style={{
          background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)'
        }}
      />
      <div className="relative z-10">
        <Navigation />
        <main className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
          <div className="mx-auto max-w-5xl">
            {/* Header */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="mb-12 text-center"
            >
              <h1 className="mb-4 text-5xl font-light text-white">
                Only <span className="text-red-400">One Plan</span>
              </h1>
              <p className="mx-auto max-w-2xl text-white/70 font-light">
                Unlimited Credits. One-time purchase. No studio, no travel, no wardrobe.
              </p>
            </motion.div>

            {/* Single Plan Card */}
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mx-auto max-w-xl"
            >
              <div className="relative overflow-hidden rounded-2xl border border-white/15 bg-gradient-to-br from-white/10 via-white/5 to-transparent p-[2px]">
                <div className="rounded-2xl bg-gradient-to-b from-white/10 to-transparent p-6">
                  <div className="relative rounded-xl bg-gradient-to-r from-white to-red-100 p-[1px]">
                    <div className="rounded-xl bg-black/70 p-6">
                      <div className="mb-6 text-center">
                        <div className="inline-flex items-center gap-2 rounded-full bg-red-500/20 px-3 py-1 text-xs text-red-200">
                          <Icon icon="mdi:fire" className="h-4 w-4 text-red-300" /> Most Popular
                        </div>
                        <h2 className="mt-4 text-2xl font-medium text-white">Unlimited Credit Plan</h2>
                        <p className="mt-2 text-white/70 font-light">Buy once, create forever</p>
                        <div className="mt-4 text-5xl text-red-300">$10</div>
                      </div>

                      <ul className="mb-6 space-y-3">
                        {[ 
                          'Unlimited prompt purchases',
                          'Unlimited prompt enhancements',
                          'Priority support',
                          'All current and future prompts included',
                          'Commercial usage rights',
                        ].map((f) => (
                          <li key={f} className="flex items-start text-sm text-white/85">
                            <Icon icon="mdi:check" className="mr-2 mt-0.5 h-4 w-4 text-red-300" /> {f}
                          </li>
                        ))}
                      </ul>

                      <button
                        onClick={handleCheckout}
                        disabled={loading || !unlimited}
                        className="group relative inline-flex w-full items-center justify-center rounded-lg bg-gradient-to-r from-red-500 to-red-600 px-6 py-3 text-white shadow-[0_0_45px_rgba(255,0,0,0.35)] transition-transform hover:scale-[1.02] disabled:opacity-60"
                      >
                        {loading ? 'Processing…' : 'Get Unlimited Credits'}
                      </button>

                      {error && (
                        <p className="mt-3 text-center text-sm text-red-300">{error}</p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  );
}