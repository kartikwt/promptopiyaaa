'use client';

import { motion } from 'framer-motion';
import { Icon } from '@iconify/react';
import Link from 'next/link';
import Navigation from '@/app/components/Navigation';

export default function PaymentCancel() {
  return (
    <div className="min-h-screen">
      {/* Background */}
      <div 
        className="fixed inset-0 z-0" 
        style={{
          background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)'
        }}
      />
      
      <div className="relative z-10">
        <Navigation />
        
        <main className="pt-20 pb-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center">
            <motion.div
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              className="bg-white/5 backdrop-blur-sm border border-red-500/30 rounded-2xl p-8"
            >
              {/* Cancel Icon */}
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6"
              >
                <Icon icon="mdi:close" className="w-8 h-8 text-red-400" />
              </motion.div>

              <motion.h1
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="text-3xl font-light text-white mb-4"
              >
                Payment Cancelled
              </motion.h1>

              <motion.p
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.6 }}
                className="text-white/70 font-light mb-8"
              >
                No worries! Your payment was cancelled and no charges were made. 
                You can try again anytime or explore our free content.
              </motion.p>

              {/* Action Buttons */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.8 }}
                className="flex flex-col sm:flex-row gap-4 justify-center mb-8"
              >
                <Link
                  href="/pricing"
                  className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-8 py-3 rounded-lg transition-all font-light flex items-center justify-center space-x-2"
                >
                  <Icon icon="mdi:credit-card" className="w-5 h-5" />
                  <span>Try Again</span>
                </Link>
                
                <Link
                  href="/"
                  className="border border-red-500/50 hover:border-red-500 text-red-400 hover:text-red-300 px-8 py-3 rounded-lg transition-all font-light flex items-center justify-center space-x-2"
                >
                  <Icon icon="mdi:home" className="w-5 h-5" />
                  <span>Back Home</span>
                </Link>
              </motion.div>

              {/* Help Section */}
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 1 }}
                className="p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg"
              >
                <p className="text-blue-400 text-sm font-light mb-2">Need help?</p>
                <p className="text-white/70 text-sm font-light">
                  Remember, new users get 20 free credits to try out our prompts and enhancer. 
                  You can explore the platform risk-free!
                </p>
              </motion.div>
            </motion.div>
          </div>
        </main>
      </div>
    </div>
  );
}