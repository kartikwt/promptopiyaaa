'use client';

import Navigation from '@/app/components/Navigation';
import PromptEnhancer from '@/app/components/PromptEnhancer';
import { motion } from 'framer-motion';
import Link from 'next/link';
import { Icon } from '@iconify/react';

export default function EnhancerPage() {
  return (
    <div className="min-h-screen">
      {/* Background */}
      <div 
        className="fixed inset-0 z-0" 
        style={{
          background: 'linear-gradient(179deg, rgba(0,0,0,1) 9.2%, rgba(127,16,16,1) 103.9%)'
        }}
      />
      
      <div className="relative z-10">
        <Navigation />
        
        <main className="pt-20">
          {/* Header Section */}
          <section className="py-12 px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="max-w-4xl mx-auto"
            >
              <h1 className="text-5xl lg:text-6xl font-light text-white mb-6">
                AI Prompt <span className="text-red-400">Enhancer</span>
              </h1>
              <p className="text-xl text-white/70 font-light mb-12 max-w-3xl mx-auto">
                Transform your simple ideas into professional-grade cinematic prompts. 
                Our AI understands influencer photography and creates XML-structured prompts 
                optimized for character consistency and professional results.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                {[
                  { number: '0.2', label: 'Credits per enhancement', icon: 'icon-park:credit' },
                  { number: '10x', label: 'More detailed than manual', icon: 'mdi:chart-line' },
                  { number: '100%', label: 'Influencer optimized', icon: 'mdi:target' }
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2 + index * 0.1 }}
                    className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-lg p-6"
                  >
                    <Icon icon={stat.icon} className="w-8 h-8 text-red-400 mx-auto mb-3" />
                    <div className="text-2xl font-light text-white mb-2">{stat.number}</div>
                    <div className="text-white/70 text-sm font-light">{stat.label}</div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </section>

          {/* Main Enhancer Component */}
          <PromptEnhancer />

          {/* How It Works Section */}
          <section className="py-20 px-4 sm:px-6 lg:px-8">
            <div className="max-w-6xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-16"
              >
                <h2 className="text-4xl font-light text-white mb-6">
                  How It <span className="text-red-400">Works</span>
                </h2>
                <p className="text-white/70 font-light max-w-2xl mx-auto">
                  Our AI understands the nuances of cinematic influencer photography 
                  and transforms your ideas into professional-grade prompts.
                </p>
              </motion.div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {[
                  {
                    step: '1',
                    title: 'Describe Your Vision',
                    description: 'Write a simple description in plain English. Something like "fashion model in a modern studio with dramatic lighting".',
                    icon: 'mdi:pencil'
                  },
                  {
                    step: '2',
                    title: 'AI Enhancement',
                    description: 'Our Gemini-powered AI analyzes your input and creates a structured XML prompt with professional photography specifications.',
                    icon: 'mdi:magic-staff'
                  },
                  {
                    step: '3',
                    title: 'Professional Results',
                    description: 'Use the enhanced XML prompt with any AI image generator to create consistent, professional-quality influencer content.',
                    icon: 'mdi:image-multiple'
                  }
                ].map((step, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: index * 0.2 }}
                    className="text-center"
                  >
                    <div className="relative mb-6">
                      <div className="w-16 h-16 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <Icon icon={step.icon} className="w-8 h-8 text-red-400" />
                      </div>
                      <div className="absolute -top-2 -right-2 w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white text-sm font-light">
                        {step.step}
                      </div>
                    </div>
                    <h3 className="text-xl font-light text-white mb-4">{step.title}</h3>
                    <p className="text-white/70 font-light">{step.description}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* Examples Section */}
          <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/5">
            <div className="max-w-4xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="text-center mb-16"
              >
                <h2 className="text-4xl font-light text-white mb-6">
                  Enhancement <span className="text-red-400">Examples</span>
                </h2>
              </motion.div>

              <div className="space-y-8">
                <motion.div
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  className="bg-black/30 backdrop-blur-sm border border-white/10 rounded-xl p-6"
                >
                  <div className="mb-4">
                    <h3 className="text-white font-light mb-2">Input:</h3>
                    <p className="text-white/70 font-light italic">
                      &quot;A fashion influencer in a modern studio with dramatic lighting&quot;
                    </p>
                  </div>
                  
                  <div>
                    <h3 className="text-white font-light mb-2">Enhanced Output (excerpt):</h3>
                    <pre className="text-green-400 text-xs font-mono overflow-x-auto bg-black/50 p-4 rounded">
{`<prompt>
  <subject_identity>Professional fashion influencer, confident pose, engaging eye contact</subject_identity>
  <camera>
    <lens>85mm portrait lens</lens>
    <aperture>f/2.8</aperture>
    <iso>400</iso>
  </camera>
  <lighting>
    <key>Softbox key light at 45-degree angle</key>
    <fill>Large reflector for shadow fill</fill>
    <rim>Hair light from behind for separation</rim>
  </lighting>
  <!-- ... and much more -->`}
                    </pre>
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-20 px-4 sm:px-6 lg:px-8 text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="max-w-2xl mx-auto"
            >
              <h2 className="text-3xl font-light text-white mb-6">
                Ready to <span className="text-red-400">Enhance</span> Your Prompts?
              </h2>
              <p className="text-white/70 font-light mb-8">
                Join thousands of creators using AI-enhanced prompts for professional results.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  href="/"
                  className="bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white px-8 py-3 rounded-lg transition-all font-light"
                >
                  Browse Prompts
                </Link>
                <Link
                  href="/pricing"
                  className="border border-red-500/50 hover:border-red-500 text-red-400 hover:text-red-300 px-8 py-3 rounded-lg transition-all font-light"
                >
                  Get Credits
                </Link>
              </div>
            </motion.div>
          </section>
        </main>
      </div>
    </div>
  );
}